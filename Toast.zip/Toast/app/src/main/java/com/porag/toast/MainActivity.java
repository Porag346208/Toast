package com.porag.toast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Button(View view) {
        Toast.makeText(this, "button clicked", Toast.LENGTH_SHORT).show();
    }

    public void toast(View view) {

        Toast toast = Toast.makeText(this, "this is custom toast", Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.DISPLAY_CLIP_VERTICAL,10,2);
        toast.show();
    }
}